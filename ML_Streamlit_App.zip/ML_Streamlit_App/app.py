import streamlit as st
import joblib

st.set_page_config(page_title="Iris Flower Prediction", page_icon="🌸")
st.title("Iris Flower Prediction")
st.write("Enter the flower measurements to predict its species.")

@st.cache_resource
def load_model():
    return joblib.load("iris_model.pkl")

try:
    model = load_model()
except Exception:
    st.error("The model file is missing. Run `python train.py` and upload iris_model.pkl to GitHub.")
    st.stop()

flowers = ["Setosa", "Versicolor", "Virginica"]
sl = st.number_input("Sepal Length (cm)", min_value=0.1, value=5.1, step=0.1)
sw = st.number_input("Sepal Width (cm)", min_value=0.1, value=3.5, step=0.1)
pl = st.number_input("Petal Length (cm)", min_value=0.1, value=1.4, step=0.1)
pw = st.number_input("Petal Width (cm)", min_value=0.1, value=0.2, step=0.1)

if st.button("Predict"):
    values = [[sl, sw, pl, pw]]
    prediction = int(model.predict(values)[0])
    st.success(f"Predicted Flower: {flowers[prediction]}")
    confidence = max(model.predict_proba(values)[0]) * 100
    st.write(f"Prediction confidence: {confidence:.2f}%")
