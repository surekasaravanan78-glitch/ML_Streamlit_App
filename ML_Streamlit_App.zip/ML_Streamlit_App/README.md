# ML Streamlit Iris Prediction

## Run locally
1. Install Python 3.10 or newer.
2. In this folder, run `python -m pip install -r requirements.txt`.
3. Run `python train.py` to create `iris_model.pkl`.
4. Run `streamlit run app.py`.

## Deploy
Upload `app.py`, `train.py`, `requirements.txt`, and `iris_model.pkl` to a GitHub repository. In Streamlit Community Cloud select branch `main` and main file path `app.py`.

This project uses scikit-learn's built-in Iris dataset, so `iris.csv` is not required.
